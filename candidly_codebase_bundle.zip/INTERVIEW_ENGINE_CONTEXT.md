# CANDIDLY AI VOICE INTERVIEW PLATFORM - BACKEND INTERVIEW ENGINE CONTEXT (PHASE A6)

## Overview
This zip archive contains the complete backend interview engine, state machine conductor, real-time voice session runner, LLM decision router, evaluation engine, regression test suites, and end-to-end agentic simulation suite for the Candidly AI voice interview platform.

---

## Key Architecture & Core Files

### 1. Pure State Machine Conductor (`backend/app/services/interview_v2/conductor.py`)
- **Role**: Pure reducer `step(state, event) -> (new_state, effects)` driving the entire interview progression.
- **Phase A6 Core Additions**:
  - `OutboundSpeechLedger` & `OutboundSpeechSegment`: Authoritative transcript source of truth recording monotonic sequence numbers, speech IDs, request IDs, semantic kinds (`bridge`, `ack`, `transition`, `question`, `qa_reply`, `closing`), exact text, action, effective action, question ID, skill name, and playback timestamps.
  - `DecisionContextSnapshot`: Immutable context snapshot with SHA-256 hashes for normalized answers and questions. Rejects stale decisions and discards mismatched speculations.
  - Action-Aware Ack Policy: Max 12 words, 1 short sentence, no '?', no praise, verbatim runs $\ge 5$ words blocked, opener rotation, bridge suppression/opener stripping. Off-topic turns speak NO ack about unrelated content.
  - Candidate Q&A Grounding: Validates answers against `extract_job_facts()`. Unsupported topics (salary, bonus, 401k, equity, team size, manager, autonomy, mentoring, 6-month success criteria) strictly emit `APPROVED_QA_DEFERRAL`:
    > *"I don't have that detail in our job description, but our hiring team will follow up with you on that. Anything else?"*
  - Closing transition: Recognizes candidate close (`is_qa_done_phrase()`), speaks blueprint closing line, and marks session `COMPLETED`.

### 2. Session Runner & Speculative Lookahead (`backend/app/services/interview_v2/runner.py`)
- **Role**: High-concurrency asyncio runner managing WebSocket communication, Deepgram Aura-2 TTS synthesis, Deepgram Flux STT streaming, and speculative execution.
- **Phase A6 Core Additions**:
  - Records semantic segments to `self.speech_ledger` for `Speak`, `SpeakAck`, and `PlayBridgeClip`, marking playback start and completion events.
  - Immutable Context Hashing: Compares speculative snapshot hash to committed answer hash. On exact match, reuses decision immediately ($< 100\text{ ms}$). On mismatch (e.g., candidate appends words), discards with reason `"text_mismatch"` and requests fresh decision for the complete final answer.
  - Shared Prompt Builders: Identical grounding and schema constraints for speculative and final LLM calls (`_build_decision_prompt`, `_build_qa_prompt`).
  - Provider and timing attribution: Accurately logs provider, model, region, TTFT, and total duration from router.

### 3. LLM Router (`backend/app/services/llm_router.py`)
- **Role**: Multi-provider LLM routing with Amazon Bedrock primary and Google Gemini backup.
- **Configuration**:
  - Primary: Amazon Bedrock Converse API (`apac.amazon.nova-lite-v1:0` in `ap-southeast-2`).
  - Fallback: Google Gemini rotational keys (`gemini-3.5-flash-lite`).
  - Streaming: `extract_action_and_ack_from_json_stream()` parses `action`, `no_experience`, and `ack` in sequence before triggering `AckReady`.

### 4. End-to-End Simulation Engine (`scripts/simulate_agentic_interview.py`)
- **Role**: Production-grade acceptance simulation running 3 complete interviews:
  - **Run A — Vague then Strong**: Vague concurrency $\to$ clarify $\to$ strong $\to$ escalation $\to$ candidate Q&A (1 supported tech question + 1 unsupported compensation question deferred $\to$ closing).
  - **Run B — Off-Topic then Strong**: Off-topic espresso $\to$ re-ask without ack $\to$ strong; double off-topic parking/lunch $\to$ insufficient evidence advance with neutral line $\to$ closing.
  - **Run C — Long Answer (>150 words)**: Candidate answer of 164 words $\to$ eager prefix lookahead with extension $\to$ hash mismatch discard $\to$ fresh evaluation $\to$ closing.
- **Metrics**: Authoritative ledger segment logging, exact-match reuse rate, discard breakdown, and simulated total silence with an explicitly labelled 1,200 ms synthetic Flux wait assumption.

### 5. Regression Test Suites (`tests/`)
- `tests/test_phase_a6_regression.py`:
  - `test_intro_to_anchor_regression_100_runs`: 100/100 randomized iterations with reproducible seeds proving zero intro repeats and zero duplicate commits.
  - Candidate Q&A fact grounding & deferral tests (technologies, 6-month success, autonomy, compensation).
  - Context snapshot hash mismatch discard tests.
  - Speech sink ledger ordered segment verification.
- `tests/test_conductor_v2.py`: 70 unit tests covering reducer transitions, timers, barging, pacing, and repeat handling.
- `tests/test_runner_v2.py`: 14 unit tests covering runner concurrency, WebSocket messages, and Aura-2 TTS synthesis.
- **Total**: 92 passed / 92 tests.

---

## Complete File Manifest in this Zip
- `INTERVIEW_ENGINE_CONTEXT.md` (this architectural summary)
- `phase_a6_prompt.md` (Phase A6 specification)
- `backend/app/services/interview_v2/conductor.py`
- `backend/app/services/interview_v2/runner.py`
- `backend/app/services/interview_v2/router.py`
- `backend/app/services/interview_v2/__init__.py`
- `backend/app/services/llm_router.py`
- `backend/app/services/interview/turn_evaluator.py`
- `backend/app/services/interview/plan_materializer.py`
- `backend/app/services/interview/live_session.py`
- `backend/app/services/interview/simple_session.py`
- `backend/app/services/interview/state_machine.py`
- `backend/app/services/interview/followup_policy.py`
- `backend/app/services/interview/personalization.py`
- `backend/app/services/interview/voice_pipeline.py`
- `backend/app/services/interview/trace.py`
- `backend/app/services/interview/stt_provider.py`
- `backend/app/services/blueprint/` (validator, persistence, seniority_config, prompts, generator, contracts)
- `backend/app/services/question_generation/` (validator, persistence, prompt_builder, provider, contracts, snapshot)
- `backend/app/services/voice/` (gateway, aura_tts, flux_stt)
- `backend/app/models.py`
- `backend/app/schemas.py`
- `backend/app/main.py`
- `backend/app/database.py`
- `backend/app/budgeting.py`
- `scripts/simulate_agentic_interview.py`
- `tests/test_phase_a6_regression.py`
- `tests/test_conductor_v2.py`
- `tests/test_runner_v2.py`
