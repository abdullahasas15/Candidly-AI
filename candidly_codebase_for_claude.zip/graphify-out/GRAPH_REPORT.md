# Graph Report - CANDIDLY AI VOICE INTERVIEW PLATFORM  (2026-10-18)

## Corpus Check
- cluster-only mode — file stats not available

## Summary
- 1731 nodes · 4532 edges · 100 communities (78 shown, 19 thin omitted)
- Extraction: 94% EXTRACTED · 6% INFERRED · 0% AMBIGUOUS · INFERRED: 269 edges (avg confidence: 0.89)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `7c429a11`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- verify_r3_5.py
- test_interview_simulator.py
- SimpleInterviewCoordinator
- re
- AnalyzerEngine
- provider.py
- JobApplication (job_applications)
- schemas.py
- generator.py
- blueprint/persistence.py
- User
- blueprint/validator.py
- e2e_voice_session.py
- models.py
- llm_router.py
- _generate_single_skill_sync
- live_session.py
- LiveInterviewManager
- .handle_candidate_answer
- PacingController
- ProviderSTTService
- App.jsx
- package.json
- AsyncSession
- json
- benchmark_voice_latency.py
- InterviewCoordinatorProcessor
- voice_pipeline.py
- main.py
- sqlalchemy
- auth.py
- os
- test_realtime_interview_experience.py
- get_application_with_relations
- _enrich_jobs_with_blueprint_status
- SessionTrace
- RecruiterDashboard.jsx
- analyze_captured_audio.py
- CandidateDashboard.jsx
- numpy
- .process_frame
- check_backup_health
- typing
- simple_session.py
- stt_selfcheck.py
- TwoLaneSTTService
- materialize_blueprint_session_plan
- build_voice_pipeline_components
- time
- compare_on_captured.py
- filter_hallucinations
- check_gemini.py
- sys
- verify_r3_4c.py
- EventLoopLagMonitor
- CandidlyDeepgramSTTService
- check_gemini_health
- benchmark_r3_1_latency.py
- dependencies
- JobCreationModal.jsx
- budgeting.py
- Any
- SimpleMockSTTService
- get_backup_api_key
- patch-pipecat.js
- env.py
- dump_schema_doc.py
- scan_blueprints.py
- download_models.py
- Web Capture: Elena Test Webcam Frame (scripts/test_elena_webcam.jpg)
- Scanned Resume Fixture: Samantha Vance (test_scanned_candidate.pdf)
- Scanned Resume Fixture: Elena Rostova (test_scanned.pdf)
- Synthetic Solid-Color Frame Fixture (programmatically generated test image, not a real camera capture)
- Optional Apple Silicon local voice stack: pipecat-ai, silero-vad, parakeet-mlx, mlx-audio (unpinned; downloads model weights on first use)
- regenerate_interview_plan
- update_job_blueprint_endpoint
- .normalize_response
- db.sh
- print_latency_stats.py
- Root div #root — Vite/React mount point in index.html
- main.jsx
- interview/__init__.py
- question_generation/__init__.py
- Package.swift
- build_apple_stt.sh
- start_servers.sh
- stop_servers.sh
- BaseModel
- field_validator
- FrameProcessor
- SmallWebRTCConnection
- Configuration & utilities group: python-dotenv>=1.0.1, python-multipart>=0.0.9
- Database & vector store group: sqlalchemy>=2.0.30, greenlet>=3.1.0, asyncpg>=0.29.0, pgvector>=0.3.0, alembic>=1.13.0
- Document & resume parsing group: pdfplumber>=0.11.0, python-docx>=1.1.0, ocrmac>=1.0.0
- FastAPI web-framework group: fastapi>=0.115.0, uvicorn[standard]>=0.30.0, pydantic>=2.8.0, pydantic-settings>=2.4.0
- graphifyy — knowledge graph & agent memory tool dependency (unpinned)
- Security & authentication group: pyjwt>=2.9.0, bcrypt>=4.0.0, google-auth>=2.30.0

## God Nodes (most connected - your core abstractions)
1. `InterviewCoordinatorProcessor` - 59 edges
2. `JobPosting` - 37 edges
3. `SimpleInterviewCoordinator` - 36 edges
4. `evaluate_interview_session()` - 33 edges
5. `PacingController` - 26 edges
6. `stream_section_turn_decision()` - 26 edges
7. `InterviewSession` - 25 edges
8. `ProviderSTTService` - 25 edges
9. `_generate_single_skill_sync()` - 24 edges
10. `get_application_with_relations()` - 24 edges

## Surprising Connections (you probably didn't know these)
- `run_e2e_r3_test()` --uses--> `InterviewPhase`  [INFERRED]
  scripts/test_r3_e2e_simulation.py → backend/app/services/interview/state_machine.py
- `run_validation()` --uses--> `InterviewPhase`  [INFERRED]
  scripts/test_realtime_interview_experience.py → backend/app/services/interview/state_machine.py
- `SessionSimulatorHarness` --uses--> `InterviewSession`  [INFERRED]
  scripts/test_interview_simulator.py → backend/app/models.py
- `SessionSimulatorHarness` --uses--> `PacingController`  [INFERRED]
  scripts/test_interview_simulator.py → backend/app/services/interview/state_machine.py
- `run_e2e_r3_test()` --uses--> `InterviewQuestion`  [INFERRED]
  scripts/test_r3_e2e_simulation.py → backend/app/models.py

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Core backend dependency groups pinned in requirements.txt (web framework, database/vector store, Gemini AI, document parsing, async transport, config utils, security/auth, graphifyy)** — requirements_txt_fastapi_group, requirements_txt_database_vector_group, requirements_txt_google_genai, requirements_txt_doc_parsing_group, requirements_txt_async_http_group, requirements_txt_config_utils_group, requirements_txt_security_auth_group, requirements_txt_graphifyy [EXTRACTED 0.95]
- **Vite React bootstrap chain in index.html: #root mount div, /src/main.jsx module script, and inline theme-flash prevention script** — frontend_index_html_vitemount, frontend_index_html_main_jsx_ref, frontend_index_html_theme_flash_script [EXTRACTED 0.95]
- **Blueprint document structure (blueprint -> sections -> questions/expectations)** — docs_schema_interviewblueprint, docs_schema_blueprintsection, docs_schema_blueprintquestion, docs_schema_blueprintexpectation [EXTRACTED 1.00]
- **Live interview assessment pipeline (questions -> transcript -> evaluation -> skill scores -> coverage)** — docs_schema_interviewsession, docs_schema_interviewquestion, docs_schema_interviewtranscriptturn, docs_schema_interviewevaluation, docs_schema_interviewskillscore, docs_schema_sessionexpectationcoverage [EXTRACTED 1.00]
- **Optional Apple Silicon local voice stack: pipecat-ai/silero-vad/parakeet-mlx/mlx-audio group plus planned Smart Turn v3 adapter integration** — requirements_voice_macos_txt_voice_stack_group, requirements_voice_macos_txt_smart_turn_v3 [INFERRED 0.75]
- **Rendered blueprint dumps, matrix validation & schema blueprint tables** — docs_dump_ai_engineer_mid, docs_dump_sde_entry, docs_matrix_summary, docs_schema_interviewblueprint [INFERRED 0.85]

## Communities (100 total, 19 thin omitted)

### Community 0 - "verify_r3_5.py"
Cohesion: 0.05
Nodes (55): STT provider readiness for the pre-flight gate (Part 4). Blocks "Enter…, stt_status(), AppleSpeechProcess, get_stt_provider_status(), helper_is_built(), macos_major_version(), _parse_jsonl(), _pcm16_to_wav() (+47 more)

### Community 1 - "test_interview_simulator.py"
Cohesion: 0.08
Nodes (62): InterviewEvaluation, InterviewIntegrityEvent, InterviewQuestion, InterviewSkillScore, InterviewTranscriptTurn, decide_followup(), detect_fast_intent(), FastIntentResult (+54 more)

### Community 2 - "SimpleInterviewCoordinator"
Cohesion: 0.06
Nodes (35): LiveInterviewRunner, _on_close(), SmallWebRTCConnection, Manages the Pipecat pipeline runner, connection, and coordinator for a session., Pre-start the STT provider at pipeline assembly (no first-turn cold boot)., Pre-render the personalized greeting + ready-check during pre-flight so 'Begin'…, Pre-warm the Apple STT helper during pre-flight (Part 4: Enter blocked until…, Callback invoked when SmallWebRTC creates a peer connection. (+27 more)

### Community 3 - "re"
Cohesion: 0.06
Nodes (59): Split LLM response into clean spoken sentences for low-latency TTS chunking., split_into_spoken_sentences(), detect_discrepancies(), extract_categorized_skills(), extract_certifications(), extract_contact_info(), extract_projects(), extract_schooling_education() (+51 more)

### Community 4 - "AnalyzerEngine"
Cohesion: 0.07
Nodes (36): AnalyzerInput, AsyncStream, AVAudioConverter, AVAudioFormat, AVFoundation, Bool, Data, Foundation (+28 more)

### Community 5 - "provider.py"
Cohesion: 0.09
Nodes (47): _generate_application_questions(), [DEPRECATED] Legacy question generation off-request; preserved for legacy…, AuditEvent, InterviewGenerationRun, get_gemini_client(), Return active Gemini Client (cached for current key in rotation)., Reset the Gemini client pool and reload keys from environment., Pre-flight warmup of Gemini client connection. (+39 more)

### Community 6 - "JobApplication (job_applications)"
Cohesion: 0.06
Nodes (53): Job Interview Blueprint: AI Engineer (LLM & GenAI) (Mid), Skill: Data & Retrieval Pipelines (P1), Semantic safety guardrails & fallback model cascades, Hybrid search + cross-encoder reranking pipeline, Incremental change data capture for vector index sync, LLM-as-a-judge evaluation calibrated against human ground truth, Skill: LLM Application Design & RAG (P0), Multi-hop reasoning graphs / agentic retrieval under latency limits (+45 more)

### Community 7 - "schemas.py"
Cohesion: 0.07
Nodes (50): AuditEventResponse, CandidateApplicationPublicResponse, CandidateApplicationResponse, CandidateIdVerificationResponse, CandidateInterviewQuestionResponse, CandidateInterviewSessionResponse, CandidateResumeResponse, CandidateSafeEvaluationSummary (+42 more)

### Community 8 - "generator.py"
Cohesion: 0.08
Nodes (44): BlueprintApprovalRequest, BlueprintExpectationOut, BlueprintQuestionOut, BlueprintSectionOut, BlueprintUpdatePayload, ExpectationDraft, InterviewBlueprintOut, LLMReviewItem (+36 more)

### Community 9 - "blueprint/persistence.py"
Cohesion: 0.14
Nodes (36): Background worker for job blueprint generation with live progress reporting., _run_blueprint_generation_background(), BlueprintSection, InterviewBlueprint, JobPosting, approve_job_blueprint(), compute_job_input_hash(), ensure_job_blueprint() (+28 more)

### Community 10 - "User"
Cohesion: 0.07
Nodes (42): append_transcript_turn(), approve_interview_plan(), approve_job_blueprint_endpoint(), begin_interview_session(), commit_interview_turn(), create_integrity_event(), create_interview_session(), end_interview_session() (+34 more)

### Community 11 - "blueprint/validator.py"
Cohesion: 0.13
Nodes (34): BatchedBlueprintReviewResponse, ValidationIssue, get_seniority_profile(), normalize_seniority(), Any, Shared Seniority Level Configuration for Budgeting, Generation, and Validation., Normalize user or legacy seniority string to entry|mid|senior|lead., Retrieve full seniority profile config for a given seniority string. (+26 more)

### Community 12 - "e2e_voice_session.py"
Cohesion: 0.11
Nodes (33): best_window_wer(), build_capture_wav(), contains_tail(), db_turns(), frontend_up(), main(), Path, Preflight sentence tiles -> answer-1 tiles -> answer-2 tiles, 2.8s gaps. (+25 more)

### Community 13 - "models.py"
Cohesion: 0.16
Nodes (29): BlueprintExpectation, BlueprintQuestion, CandidateApplication, CandidateIdVerification, CandidatePersonalization, CandidateResume, InterviewFeedback, InterviewSession (+21 more)

### Community 14 - "llm_router.py"
Cohesion: 0.13
Nodes (29): AsyncOpenAI, call_backup_chat_sync(), CandidateDataFailoverBlockedError, clean_json_markdown(), get_async_nvidia_client(), get_async_openrouter_client(), get_nvidia_api_key(), get_nvidia_client() (+21 more)

### Community 15 - "_generate_single_skill_sync"
Cohesion: 0.11
Nodes (24): _gen_bounded(), _generate_single_skill_sync(), Synchronously generate and validate a single skill section with caching and…, Run one consolidated batched LLM quality review across all sections of a…, run_batched_blueprint_llm_review_sync(), compute_personalization_hash(), generate_candidate_personalization(), AsyncSession (+16 more)

### Community 16 - "live_session.py"
Cohesion: 0.11
Nodes (26): asyncio, answer_candidate_closing_question(), make_degraded_rule_based_decision(), pick_neutral_bridge(), Any, Asynchronously evaluate and update session_expectation_coverage without…, Validate that every evidence quote in coverage is a verbatim substring of…, Fallback when live Gemini calls fail or are rate-limited. Selects stored probe… (+18 more)

### Community 17 - "LiveInterviewManager"
Cohesion: 0.10
Nodes (10): InterviewerBusyError, LiveInterviewManager, Any, RuntimeError, Singleton registry of active live interview rooms with single-session MLX…, Return True if another live session is currently active on this local MLX…, R3.5 simple mode: commit the candidate's current answer (state COMMITTED)., Ephemeral probe for pre-flight network checks. (+2 more)

### Community 18 - ".handle_candidate_answer"
Cohesion: 0.14
Nodes (12): _on_sentence_chunk(), Execute the sectioned live delivery state machine (Checkpoint R3.4)., Advance section pointer and announce section transition or wrap (R3.4 Phase…, Speak one neutral filler ('Mm-hm.') once if decision takes > 1.5s, keeping…, Processes candidate STT transcription and advances conversation flow with…, Invite the candidate to ask any questions before final closing (Part B5)., Final closing thank-you and next steps (Part B5)., Commits accumulated speech segments into a single full candidate turn. (+4 more)

### Community 19 - "PacingController"
Cohesion: 0.14
Nodes (11): PacingController, Any, Manages time allocation, follow-up shedding, P2/P1 skipping, and P0 grace…, Grant a one-time +5m grace extension ONLY if time is nearly out and a P0…, Drop follow-ups FIRST when behind schedule or per-question budget is exceeded., Behind schedule drops probes first (before escalation and section shedding)., Behind schedule drops escalation next (after probes, before section skipping)., Shedding order: P2 dropped, then P1 dropped, NEVER P0 dropped. (+3 more)

### Community 20 - "ProviderSTTService"
Cohesion: 0.11
Nodes (12): ProviderSTTService, Single-pass segment finalization: provider already transcribed this audio., R3.5 provider-based STT (apple_speechanalyzer / apple_sfspeech strategy). One…, Stitch Apple's sliding volatile window into a stable cumulative utterance., Feed the coalesced ~100ms chunk buffer now (end of speech / echo gate)., Clear utterance accumulation when moving to a new interview turn., R3.5b turn-commit finalize: the analyzer's FLUSHed final is the answer of…, R3.5b caption cadence metrics for the current speech window. (+4 more)

### Community 21 - "App.jsx"
Cohesion: 0.21
Nodes (15): App(), AuthModal(), CandidateDashboard(), DemoModal(), Footer(), Header(), Hero(), HowWeEvaluate() (+7 more)

### Community 22 - "package.json"
Cohesion: 0.08
Nodes (24): devDependencies, autoprefixer, postcss, tailwindcss, vite, @vitejs/plugin-react, name, private (+16 more)

### Community 23 - "AsyncSession"
Cohesion: 0.13
Nodes (25): get_application_scorecard(), get_audit_logs(), get_blueprint_generation_status_endpoint(), get_candidate_safe_summary(), get_interview_live_status(), get_interview_session(), get_job_blueprint_endpoint(), get_me() (+17 more)

### Community 24 - "json"
Cohesion: 0.19
Nodes (21): RoleTemplate, Role Templates package., extract_template_skills_for_seniority(), get_all_role_templates(), get_role_template_by_id(), get_role_template_by_key(), load_role_templates(), Any (+13 more)

### Community 25 - "benchmark_voice_latency.py"
Cohesion: 0.11
Nodes (17): KokoroTTSService, _load_kokoro_singleton(), _load_parakeet_singleton(), TTS service utilizing Kokoro-82M via mlx-audio on Apple Silicon with static…, Generate smooth synthetic audio frames for mock mode / lipsync timing., Synthesize text into raw PCM audio chunks with cache lookup & first-audio…, Pre-synthesize a phrase into `_STATIC_TTS_CACHE` so playback starts in <1ms., Warm up Parakeet STT, Kokoro TTS, Silero VAD, Smart Turn v3, and Gemini client… (+9 more)

### Community 26 - "InterviewCoordinatorProcessor"
Cohesion: 0.11
Nodes (11): InterviewCoordinatorProcessor, AsyncSession, FrameProcessor, Orchestrates interview phases, streaming turn decisions, pacing, silence…, Lane 1 interim caption: update UI live as words are spoken., Lane 2 accuracy segment: append to accumulated speech and update UI., Schedule turn commit with Smart Turn gating (R3.4c): - Silence required before…, Query DB to resume sequence_number and session state safely (supports… (+3 more)

### Community 27 - "voice_pipeline.py"
Cohesion: 0.08
Nodes (23): clean_resample_16k_mono(), Local Mac voice-pipeline integration for Candidly AI. Stack components: -…, Cleanly resample 16-bit PCM audio to 16kHz mono without chunk-boundary…, collections, collections_abc, pipecat_audio_turn_smart_turn_local_smart_turn_v3, pipecat_audio_vad_silero, pipecat_audio_vad_vad_analyzer (+15 more)

### Community 28 - "main.py"
Cohesion: 0.10
Nodes (21): ai_health_check(), BlueprintGenerationTask, delete_job(), generate_blueprint_for_job_endpoint(), health_check(), lifespan(), Pre-flight speech check (R3.5 Part 4): the candidate reads a sentence in the…, Withdraw candidate application and completely wipe out all data regarding that… (+13 more)

### Community 29 - "sqlalchemy"
Cohesion: 0.15
Nodes (14): upgrade(), downgrade(), upgrade(), downgrade(), upgrade(), downgrade(), upgrade(), downgrade() (+6 more)

### Community 30 - "auth.py"
Cohesion: 0.13
Nodes (20): get_db(), create_access_token(), decode_access_token(), get_current_user(), get_optional_current_user(), hash_password(), Any, AsyncSession (+12 more)

### Community 31 - "os"
Cohesion: 0.15
Nodes (14): R3.5: Pluggable STT provider layer for Candidly live interviews. Providers…, cleanup_old_debug_sessions(), is_audio_capture_enabled(), is_turn_trace_enabled(), Turn and Audio Tracing for Candidly Voice Interview Sessions. Controls: -…, Auto-deletes debug sessions older than max_age_days., dataclasses, loguru (+6 more)

### Community 32 - "test_realtime_interview_experience.py"
Cohesion: 0.20
Nodes (13): base64, httpx, pil, pipecat_processors_frameworks_rtvi_frames, run_integration_test(), test_auth_and_candidate_flow(), test_storage_integrity(), create_test_accounts() (+5 more)

### Community 33 - "get_application_with_relations"
Cohesion: 0.13
Nodes (21): _candidate_application_payload(), finalize_application_submission(), get_application(), get_application_with_relations(), Update speech_speed, captions_enabled, or recording_consent (Part F3, G1, G3)., Allow recruiter to edit question text, key points, priority, follow-up depth,…, Serialize an application without recruiter-only job or interview data., review_discrepancy_flag() (+13 more)

### Community 34 - "_enrich_jobs_with_blueprint_status"
Cohesion: 0.13
Nodes (19): apply_to_job(), create_application(), create_job(), create_practice_interview(), _enrich_jobs_with_blueprint_status(), get_job(), list_jobs(), _public_job_payload() (+11 more)

### Community 35 - "SessionTrace"
Cohesion: 0.18
Nodes (7): Any, lane: 'lane1_streaming' | 'lane2_accuracy, R3.5b: COMMIT carries the text-of-record chain — live partials vs the…, action: 'start' | 'stop' | 'prewarm, Manages logging of turns, events, metrics, and audio captures for a session., action: 'speech_start' | 'speech_stop, SessionTrace

### Community 36 - "RecruiterDashboard.jsx"
Cohesion: 0.25
Nodes (12): ApplicationWizard(), formatSeniority(), SENIORITY_MAP, CandidateJobListing(), formatSeniority(), SENIORITY_MAP, ApplicantDetailModal(), JobDetailModal() (+4 more)

### Community 37 - "analyze_captured_audio.py"
Cohesion: 0.24
Nodes (17): _analyze_session(), analyze_sessions(), _garble_flags(), _iter_events(), _latency_stats(), main(), _median(), _non_latin_hits() (+9 more)

### Community 38 - "CandidateDashboard.jsx"
Cohesion: 0.18
Nodes (10): LiveInterviewRoom(), ORB_THEMES, STATE_PILLS, describeSttProvider(), float32ToPcm16Base64(), isAppleProvider(), PreFlightCheckModal(), sttStatusCache (+2 more)

### Community 39 - "numpy"
Cohesion: 0.29
Nodes (15): numpy, convert_to_16k_mono_pcm(), generate_60s_answer(), generate_all(), generate_kokoro_passage(), generate_quiet_speech_minus_30db(), generate_say_passage(), Path (+7 more)

### Community 40 - ".process_frame"
Cohesion: 0.13
Nodes (8): _is_backchannel(), Frame, FrameDirection, Marks the interview session completed in DB and triggers the Evidence-Anchored…, Record exact spoken prefix and was_interrupted=True when candidate barges in…, MockFrameCollector, Collects downstream frames from the processor., run_validation()

### Community 41 - "check_backup_health"
Cohesion: 0.18
Nodes (15): can_failover_candidate_data(), check_all_llm_health(), check_backup_health(), check_bedrock_health(), check_tokenharbor_health(), _extract_message_text(), is_failover_enabled(), Any (+7 more)

### Community 42 - "typing"
Cohesion: 0.19
Nodes (10): CandidatePersonalizationOutput, Candidate Personalization Service (Checkpoint R3.2). Performs one structured…, _sanitize_probe_text(), Runtime Interview Plan Materializer (Checkpoint R3.3). Pins approved…, BaseModel, field_validator, logging, pydantic (+2 more)

### Community 43 - "simple_session.py"
Cohesion: 0.18
Nodes (12): _normalize_for_phrase_match(), R3.5 simple interview mode: a deterministic, scripted interviewer. Configured…, Return (remaining_text, phrase_was_spoken). Detects commit phrases anywhere., _remove_commit_phrase(), _strip_commit_phrases(), is_acoustic_echo(), pre_synthesize_phrase(), Async helper to pre-render a greeting or static phrase into the TTS cache. (+4 more)

### Community 44 - "stt_selfcheck.py"
Cohesion: 0.19
Nodes (12): check_term_accuracy(), compute_wer(), load_asr_models(), any, Path, Transcribes a wav file with the given model, returning (text, elapsed_seconds)., Run automated STT self-check benchmark comparing Whisper, Parakeet, and…, Computes Word Error Rate (WER) using Levenshtein distance on word tokens. (+4 more)

### Community 45 - "TwoLaneSTTService"
Cohesion: 0.18
Nodes (7): Two-Lane STT service for Candidly AI (Part 2): - Lane 1 (Interim): Fast…, Explicitly set bot speaking status for echo suppression gating., Lane 1: fast streaming captions every ~400ms for live visual feedback., TwoLaneSTTService, SegmentedSTTService, VADUserStartedSpeakingFrame, VADUserStoppedSpeakingFrame

### Community 46 - "materialize_blueprint_session_plan"
Cohesion: 0.18
Nodes (12): get_application_interview_session(), list_candidate_applications(), Return the generated candidate-safe session, or an actionable pipeline status., Retrieve applications for the candidate. NEVER automatically applies candidate…, Run candidate personalization and materialize blueprint interview session off-…, _run_candidate_personalization(), clean_role_title_for_speech(), materialize_blueprint_session_plan() (+4 more)

### Community 47 - "build_voice_pipeline_components"
Cohesion: 0.17
Nodes (8): build_voice_pipeline_components(), CandidlyDeepgramTTSService, Frame, FrameDirection, Deepgram Aura real-time WebSocket TTS service with first-audio latency tracking., Constructs the configured voice components for Pipecat with STT provider…, DeepgramTTSService, SmallWebRTCConnection

### Community 48 - "time"
Cohesion: 0.42
Nodes (11): scipy_io_wavfile, main(), Any, scripts/verify_r3_4b.py Comprehensive verification and empirical measurement…, test_60s_transcript_latency(), test_decision_call_benchmark_10_answers(), test_echo_gate(), test_fragment_guard_and_intents() (+3 more)

### Community 49 - "compare_on_captured.py"
Cohesion: 0.25
Nodes (9): argparse, difflib, glob, highlight_diff(), main(), scripts/compare_on_captured.py Run Parakeet and Whisper on captured audio…, Highlight disagreements between two strings using ANSI colors., Replay and offline comparison for a recorded voice interview session. Usage:… (+1 more)

### Community 50 - "filter_hallucinations"
Cohesion: 0.22
Nodes (7): _local_transcribe(), filter_hallucinations(), _load_nemotron_singleton(), _load_whisper_singleton(), Filter ASR hallucinations on silence or repeated phrase loops., Lane 2: Accuracy segmented ASR on VAD stop with sequence tagging and guards., ndarray

### Community 51 - "check_gemini.py"
Cohesion: 0.20
Nodes (9): dotenv, google, google_genai, Script to verify all AI/LLM providers: 1. Primary Provider: Google Gemini with…, check_and_cleanup_old_sessions(), main(), Path, scripts/check_trace_ready.py Checks development debug trace and audio capture… (+1 more)

### Community 52 - "sys"
Cohesion: 0.29
Nodes (8): main(), print_script(), Print Interview Script CLI (Checkpoint R3.6). Usage: PYTHONPATH=. python…, format_rel_time(), get_latest_session_id(), print_timeline(), Print human-readable timeline for a voice interview session. Usage:…, sys

### Community 53 - "verify_r3_4c.py"
Cohesion: 0.31
Nodes (8): main(), Any, scripts/verify_r3_4c.py Comprehensive verification and empirical benchmark…, run_20_case_benchmark(), test_barge_in(), test_failure_safety(), test_turn_timing(), unittest_mock

### Community 54 - "EventLoopLagMonitor"
Cohesion: 0.29
Nodes (4): AbstractEventLoop, EventLoopLagMonitor, Monitors asyncio event-loop lag to detect UI or frame processing stalls (Part…, test_event_loop_lag()

### Community 55 - "CandidlyDeepgramSTTService"
Cohesion: 0.20
Nodes (3): CandidlyDeepgramSTTService, Deepgram real-time streaming STT service adapted for the Candidly interview…, DeepgramSTTService

### Community 56 - "check_gemini_health"
Cohesion: 0.31
Nodes (4): check_gemini_health(), GeminiKeyManager, Manages 3-key Gemini rotation: - Starts at GEMINI_API_KEY1. - If Key 1 fails…, Test primary Gemini API connectivity across all 3 rotation keys.

### Community 57 - "benchmark_r3_1_latency.py"
Cohesion: 0.31
Nodes (7): Warm up Gemini client connection and endpoint before live sessions., warm_gemini_client(), benchmark_template(), calc_percentiles(), main(), Any, R3.1 Live Model Per-Turn Decision Latency Benchmark. Measures per-turn decision…

### Community 58 - "dependencies"
Cohesion: 0.22
Nodes (9): dependencies, clsx, lucide-react, @pipecat-ai/client-js, @pipecat-ai/small-webrtc-transport, react, react-dom, tailwind-merge (+1 more)

### Community 59 - "JobCreationModal.jsx"
Cohesion: 0.33
Nodes (6): BlueprintReviewEditor(), JobCreationModal(), ROLE_DETAILS, SENIORITY_OPTIONS, TEMPLATE_CARD_META, VAGUE_SKILL_NAMES

### Community 60 - "budgeting.py"
Cohesion: 0.36
Nodes (6): calculate_blueprint_section_budgets(), calculate_question_budget(), Any, Budgeting mathematics for Layer 1 Job Blueprint sections. Fixed Overhead: 6.0…, Implements Part 2: Time Limits & Question Budgeting Mathematics 1. Operational…, math

### Community 62 - "SimpleMockSTTService"
Cohesion: 0.25
Nodes (3): Deterministic STT used by the R3.5 verification suite (scripted answer queue)., Simulate a full spoken answer finishing (partials + final chunk)., SimpleMockSTTService

### Community 63 - "get_backup_api_key"
Cohesion: 0.25
Nodes (8): get_backup_api_key(), get_bedrock_api_key(), get_llm_api_key(), Retrieve first available backup provider API key (OpenRouter or NVIDIA)., Backward compatibility alias returning backup API key., Backward compatible accessor., Startup verification: check that backup provider supports structured JSON…, verify_backup_structured_output()

### Community 64 - "patch-pipecat.js"
Cohesion: 0.25
Nodes (7): __dirname, __filename, filesToPatch, frontendDir, ref_fs, ref_path, ref_url

### Community 65 - "env.py"
Cohesion: 0.33
Nodes (5): do_run_migrations(), run_async_migrations(), Connection, logging_config, sqlalchemy_engine

### Community 66 - "dump_schema_doc.py"
Cohesion: 0.38
Nodes (6): Candidly Database Schema Reference, inspect, generate_schema_doc(), main(), Inspects SQLAlchemy models and writes docs/SCHEMA.md., sqlalchemy_inspection

### Community 67 - "scan_blueprints.py"
Cohesion: 0.52
Nodes (6): check_text_for_code_request(), main(), Scan blueprints and role templates for code-request patterns and mark offending…, scan_database_blueprints(), _scan_database_blueprints_async(), scan_role_templates()

### Community 68 - "download_models.py"
Cohesion: 0.40
Nodes (5): huggingface_hub, download_all(), get_dir_size_mb(), Path, Download and report sizes of models required for Candidly voice interview…

### Community 69 - "Web Capture: Elena Test Webcam Frame (scripts/test_elena_webcam.jpg)"
Cohesion: 0.47
Nodes (6): Elena Test Candidate Persona (stand-in candidate identity for storage/verification tests), Generating Script: scripts/test_candidate_recruiter_storage.py (STEP 5 creates frame via PIL Image.new RGB (30,80,160)), Solid Navy Blue Frame (uniform RGB ~(30, 80, 160), ~320x240 JPEG, no scene content), Synthetic Capture Scene: no human subject, no desk items, no name tags or ID documents visible, Web Capture: Elena Test Webcam Frame (scripts/test_elena_webcam.jpg), Webcam Biometric Baseline Test Fixture (live_photo payload for candidate verification step)

### Community 70 - "Scanned Resume Fixture: Samantha Vance (test_scanned_candidate.pdf)"
Cohesion: 0.33
Nodes (6): Scanned Resume Fixture: Samantha Vance (test_scanned_candidate.pdf), Apple — Senior Backend Engineer (2020-2024) work history, B.S. Computer Science, UC Berkeley (2019) education, Purpose: scanned-resume parsing / OCR test fixture, Samantha Vance (fixture candidate identity), Skills: Swift, Python, Rust, PostgreSQL, Kubernetes, Redis

### Community 71 - "Scanned Resume Fixture: Elena Rostova (test_scanned.pdf)"
Cohesion: 0.33
Nodes (6): Scanned Resume Fixture: Elena Rostova (test_scanned.pdf), Elena Rostova (fixture candidate identity), Google — Systems Engineer (2020-2023) work history, MSc Distributed Computing (2019) education, Purpose: scanned-resume parsing / OCR test fixture, Skills: Rust, Python, Kubernetes, Kafka, Linux

### Community 72 - "Synthetic Solid-Color Frame Fixture (programmatically generated test image, not a real camera capture)"
Cohesion: 0.40
Nodes (6): Webcam/ID Verification Test Context (CANDIDLY platform webcam and identity-capture test suite), No Visible Subject, Scene, or Artifacts (no person, document, badge, or room items), Solid Blue Frame Content (uniform dark-blue field filling entire frame), Synthetic Solid-Color Frame Fixture (programmatically generated test image, not a real camera capture), Web Capture (scripts/test_webcam.jpg webcam-capture fixture frame), Webcam Capture Test Fixture Role (deterministic stand-in frame for webcam tests)

### Community 73 - "Optional Apple Silicon local voice stack: pipecat-ai, silero-vad, parakeet-mlx, mlx-audio (unpinned; downloads model weights on first use)"
Cohesion: 0.40
Nodes (5): Async HTTP & WebSockets group: httpx>=0.27.0, websockets>=13.0, google-genai>=0.1.0 — Gemini AI/multimodal intelligence SDK, Rationale: voice stack is local-development only; model weights download on first use and must not be installed on production API workers, Smart Turn v3 — turn-detection model to be loaded through its local model adapter (release not yet selected), Optional Apple Silicon local voice stack: pipecat-ai, silero-vad, parakeet-mlx, mlx-audio (unpinned; downloads model weights on first use)

### Community 74 - "regenerate_interview_plan"
Cohesion: 0.50
Nodes (4): get_application_interview_plan(), Preview the generated interview question plan for a candidate (Part E3)., Force-regenerate the interview question plan for an application before the…, regenerate_interview_plan()

### Community 75 - "update_job_blueprint_endpoint"
Cohesion: 0.50
Nodes (4): Update a blueprint. Copy-on-write: editing an approved blueprint automatically…, update_job_blueprint_endpoint(), BlueprintUpdatePayload, put

### Community 77 - "db.sh"
Cohesion: 0.83
Nodes (3): is_running(), run_admin(), db.sh script

### Community 78 - "print_latency_stats.py"
Cohesion: 0.67
Nodes (3): _calc_stats(), main(), Print latency statistics (count, min, p50, p90, p95, max) per stage for live…

### Community 79 - "Root div #root — Vite/React mount point in index.html"
Cohesion: 0.67
Nodes (3): Module script reference to /src/main.jsx (React bootstrap entry), Inline theme-flash prevention script (localStorage 'candidly-theme' + prefers-color-scheme dark detection), Root div #root — Vite/React mount point in index.html

## Ambiguous Edges - Review These
- `google-genai>=0.1.0 — Gemini AI/multimodal intelligence SDK` → `Optional Apple Silicon local voice stack: pipecat-ai, silero-vad, parakeet-mlx, mlx-audio (unpinned; downloads model weights on first use)`  [AMBIGUOUS]
  requirements-voice-macos.txt · relation: conceptually_related_to

## Knowledge Gaps
- **76 isolated node(s):** `AuditEvent (audit_events)`, `CandidateIdVerification (candidate_id_verification)`, `CandidateResume (candidate_resumes)`, `InterviewSkillScore (interview_skill_scores)`, `JobCertification (job_certifications)` (+71 more)
  These have ≤1 connection - possible missing edges or undocumented components. (Counts symbols only; 635 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **19 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **What is the exact relationship between `google-genai>=0.1.0 — Gemini AI/multimodal intelligence SDK` and `Optional Apple Silicon local voice stack: pipecat-ai, silero-vad, parakeet-mlx, mlx-audio (unpinned; downloads model weights on first use)`?**
  _Edge tagged AMBIGUOUS (relation: conceptually_related_to) - confidence is low._
- **Why does `InterviewCoordinatorProcessor` connect `InterviewCoordinatorProcessor` to `test_realtime_interview_experience.py`, `test_interview_simulator.py`, `SimpleInterviewCoordinator`, `SessionTrace`, `.process_frame`, `blueprint/persistence.py`, `models.py`, `live_session.py`, `LiveInterviewManager`, `.handle_candidate_answer`, `PacingController`, `time`, `verify_r3_4c.py`?**
  _High betweenness centrality (0.049) - this node is a cross-community bridge._
- **Why does `SimpleInterviewCoordinator` connect `SimpleInterviewCoordinator` to `live_session.py`, `simple_session.py`?**
  _High betweenness centrality (0.045) - this node is a cross-community bridge._
- **Why does `InterviewBlueprint (interview_blueprints)` connect `JobApplication (job_applications)` to `budgeting.py`?**
  _High betweenness centrality (0.041) - this node is a cross-community bridge._
- **Are the 11 inferred relationships involving `InterviewCoordinatorProcessor` (e.g. with `BlueprintSection` and `InterviewIntegrityEvent`) actually correct?**
  _`InterviewCoordinatorProcessor` has 11 INFERRED edges - model-reasoned connections that need verification._
- **What connects `AuditEvent (audit_events)`, `CandidateIdVerification (candidate_id_verification)`, `CandidateResume (candidate_resumes)` to the rest of the system?**
  _76 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `verify_r3_5.py` be split into smaller, more focused modules?**
  _Cohesion score 0.05420054200542006 - nodes in this community are weakly interconnected._