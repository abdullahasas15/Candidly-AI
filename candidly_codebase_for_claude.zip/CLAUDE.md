## graphify

This project has a knowledge graph at graphify-out/ with god nodes, community structure, and cross-file relationships.

Rules:
- For codebase questions, first run `graphify query "<question>"` when graphify-out/graph.json exists. Use `graphify path "<A>" "<B>"` for relationships and `graphify explain "<concept>"` for focused concepts. These return a scoped subgraph, usually much smaller than GRAPH_REPORT.md or raw grep output.
- If graphify-out/wiki/index.md exists, use it for broad navigation instead of raw source browsing.
- Read graphify-out/GRAPH_REPORT.md only for broad architecture review or when query/path/explain do not surface enough context.
- After modifying code, run `graphify update .` to keep the graph current (AST-only, no API cost).

# Master Project Context

> **Golden Rule of Schema & State**:
> **Trust `backend/app/models.py` and `docs/SCHEMA.md` over any other doc.** Always generate `docs/SCHEMA.md` via `scripts/dump_schema_doc.py` after any model change.

- **Project Goal:** Candidly is an autonomous AI voice interview and proctoring platform that conducts real-time, adaptive technical interviews using conversational speech-to-speech intelligence and 5-level behavioral rubrics. It performs end-to-end evaluation with auditable evidence retrieval, integrity monitoring, and synchronized candidate/recruiter dashboards to eliminate hiring bias and latency.
- **Tech Stack:**
  - **Backend & API:** FastAPI (Python 3.11+), Uvicorn, Pydantic v2, WebSockets
  - **Database & Vector Store:** PostgreSQL with `pgvector` (HNSW indexing for resume chunks & interview turns), SQLAlchemy 2.0 (asyncpg), Alembic
  - **AI & Reasoning Models:** Google Gemini 3.5 Flash Lite (`GEMINI_MODEL_LIVE` for single-call real-time conversational turn decision streaming), Google Gemini 3.8 Flash (`GEMINI_MODEL_PLAN` for question plan generation & `GEMINI_MODEL_JUDGE` for post-interview evidence evaluation).
  - **Voice Pipeline:** Silero VAD + Smart Turn v3, **Apple SpeechAnalyzer on-device STT (default; Swift helper `native/apple_stt/` streaming dictation) with Parakeet TDT 0.6B fallback (parakeet-mlx)**, Kokoro-82M via `mlx-audio` (streaming TTS <200ms with static phrase cache), SmallWebRTCTransport (WebRTC audio/video + RTVI data channel). Echo gate, minimum speech duration, backchannel filtering, and scripted-commit turn endpoints in simple mode.
  - **Document Processing:** pdfplumber (resume extraction & structural chunking)
  - **Proctoring & Vision:** Camera frame capture, multi-face detection, gaze tracking, audio anomaly detection
  - **Frontend:** Next.js / React, TailwindCSS, Web Audio API, WebRTC / MediaStream

---

## Architectural Blueprint & Core Workflows

### 1. Job Posting & Rubric Calibration (Recruiter)
- Configures role metadata (`job_title`, `seniority_level`, `department`, `target_tech_stack`).
- Full-scope **Job Description** (`job_description`) field in Step 1 (Workday & LinkedIn standard) with 1-click professional template generator (`handleInsertJdTemplate`) covering role mission, key responsibilities, and minimum/preferred qualifications.
- Recruiter Job Isolation: Jobs strictly scoped to creating recruiter (`recruiter_id`), ensuring recruiters only manage positions within their own portfolio.
- Configures session settings (`interview_duration_mins` default 20, `allow_grace_extension` +5m, `max_followup_depth` 1-2, `integrity_policy_tier`).
- 5-Level Behavioral Rubrics per skill (L1 Novice to L5 Expert) with weighted percentages totaling 100%.
- Custom Screening Questions (Step 6) supporting multi-format answers (single-line text, multi-line paragraph, single choice with options, yes/no binary), required validation toggles, and expected scoring rubrics.

### 2. Authentication, Authorization & Production RBAC
- **Password Security**: Passwords hashed using `bcrypt` (12 rounds) with salt. Plaintext passwords never stored.
- **Token Architecture**: Standard JSON Web Tokens (`PyJWT`, HS256) returned in `TokenResponse` (`access_token`, `token_type`, `user`).
- **Google Sign-In**: Integrated via `/api/auth/google` for quick OAuth onboarding, setting `auth_provider: "google"` and storing user avatar.
- **Role-Based Access Control**: Fast, dependency-injected RBAC (`require_role("recruiter")`, `require_role("candidate")`, `get_current_user`).
- **Job Ownership**: `JobPosting` explicitly links `recruiter_id` to the authenticated recruiter (`users.id`).
- **Zero Auto-Apply Guarantee**: Candidates strictly see "Browse Open Positions" (`/api/jobs`) upon signing in. No job is ever auto-applied or auto-linked to a candidate. Candidates must explicitly click "Apply" and submit through `ApplicationWizard.jsx`, at which point an application record (`job_applications`) is created with status `submitted`.
- **Database Clean Slate**: Truncate utility `scripts/wipe_database.py` available for testing fresh pipelines from zero records.

### 3. Candidate Application & Profile Submission (Production Implemented)
- **Multi-Step Application Wizard (`ApplicationWizard.jsx`)**:
  - Step 1: Personal profile coordinates (`full_name`, `email`, `phone`, `linkedin_url`, `portfolio_url`) auto-filled upon resume ingestion.
  - Step 2: Real resume ingestion & parsing (PDF, DOCX, TXT <= 10MB) with upload progress and live parsing feedback.
  - Step 3: Structured career history & dossier multi-tab editor:
    - **Work Experience**: role, company, timeline dates, highlights, technologies used.
    - **Schooling & Education**: degrees, institutions, fields of study/majors, graduation years, GPA/CGPA, honors.
    - **Certifications**: certification names, issuing accredited bodies, issue years, credential IDs/verification URLs.
    - **Notable Projects**: project titles, developer roles, technologies/tech stacks, descriptions, and repository links.
    - **Categorized Skills**: organized by Languages, Frameworks, Databases, Cloud & DevOps, Tools, plus general skills with instant add/remove tag chips.
  - Step 4: Fit pitch & compensation expectations (self-reported YOE input, auto-populated pitch summary, expected salary vs offered budget).
  - Step 5: Live identity verification via browser webcam (`getUserMedia`) baseline photo snapshot + optional government ID document.
  - Step 6: Final review with full candidate career credentials cards & submission confirmation.
- **Resume Ingestion & High-Precision Parsing Pipeline (`backend/app/services/resume_parser.py`)**:
  - Multi-section regex and structural segmentation (`segment_resume_sections`).
  - Contextual window extraction for educational institutions, GPAs, and honors (`extract_schooling_education`).
  - Industry certification catalog identification (`extract_certifications`).
  - Project extraction with role, tech stack, summary, and repository links (`extract_projects`).
  - Categorized engineering taxonomy organization into 5 core pillars (`extract_categorized_skills`).
  - Direct digital PDF text extraction via `pdfplumber` + Apple Vision neural OCR fallback (`ocrmac` + `pypdfium2`).
  - Non-overlapping career timeline date math to compute true cumulative experience years.
- **Candidate Dossier & Recruiter Configuration Persistence**:
  - Full relational PostgreSQL schema cleanly stores all recruiter configuration: `job_postings`, `job_skills` (with calibrated L1–L5 behavioral rubrics and percentage weights summing to 100%), `job_certifications`, `job_custom_questions`, and auto-budgeted `job_question_plans`.
  - Full candidate dossier cleanly stored in `job_applications`, `candidate_resumes` (with structured JSON for `education`, `certifications`, `projects`, `categorized_skills`, and `work_experience`), `resume_discrepancy_flags`, and `candidate_id_verification` (with live webcam snapshot).
  - Ready for customized LLM prompt & question generation pipeline in the next phase directly from these database tables.
- **Automated Discrepancy Engine**:
  - Compares stated experience against derived timeline (flags diffs > 1.0 year).
  - Verifies candidate credentials against job's minimum academic degree thresholds.
  - Populates `resume_discrepancy_flags` table with recruiter review auditability.
- **Recruiter Applicant Dossier (`ApplicantDetailModal.jsx`)**:
  - Complete candidate dossier rendering: Work History, Schooling & Degrees, Certifications, Projects, Categorized Skills.
  - Live webcam photo baseline, flag resolution toggles, fit pitch, compensation delta, and original resume downloads.

### 4. Custom LLM Question Generation & Dynamic Prompting (Next Phase)
- Build customized prompt generator utilizing data directly from `job_postings`, `job_skills`, `job_custom_questions`, `job_question_plans`, `candidate_resumes`, and `job_applications`.
- Pre-generate question plan mapped to competency weights and calibrated rubrics, with `expected_key_points` JSON stored in PostgreSQL.

### 5. Live Interview Voice Engine (R3.5 simple mode is the default)
- **INTERVIEW_MODE=simple (default, `backend/app/services/interview/simple_session.py`)**: a deterministic scripted interviewer with **zero LLM calls in the live loop** (enforced by `scripts/verify_r3_5.py`, which patches every LLM entry point to raise). Flow: welcome agenda -> intro hook -> per-skill (anchor -> escalation; `"no experience"` answer swaps to `anchor_alt` verbatim and sheds the escalation slot) -> candidate Q&A -> closing. Strict turn state machine `ASKING -> LISTENING -> COMMITTED`; bridges <= 3 words; skill transitions <= 12 words; short answers (< 4 words) get "Could you say a bit more?" exactly once per skill; timer slack under 90 s sheds remaining skills (time-skip) to candidate Q&A + closing. Bot NEVER speaks during candidate speech (ALLOW_BARGE_IN=false; UI shows "AI is speaking, please wait").
- **STT provider layer (`stt_provider.py` + `voice_pipeline.ProviderSTTService`)**: `STT_PROVIDER=auto` resolves `apple_speechanalyzer` (Apple SpeechAnalyzer on-device dictation via the Swift helper in `native/apple_stt/`, built by `scripts/build_apple_stt.sh`) -> `apple_sfspeech` -> `local_two_lane` (Parakeet+Whisper). ONE provider produces live words (RT partials, stitched via `stitch_sliding_text`) AND finals (spontaneous segment finals appended only when they add content; no second pass ever). Turn commit (`flush_and_wait`) returns stitched text in 0ms — no session rebuild mid-interview (rebuilds lose utterance heads). Echo gate pauses helper feeding while the bot speaks.
- **Turn commit triggers (first wins)**: "I'm done answering" button -> `POST /api/interview-sessions/{id}/commit-turn`; spoken "that's my answer / I'm done"; `AUTO_COMMIT_SILENCE=2.5s` after speech stops ("finishing..." ring 1s prior). Answers persist with provider + timings.
- **Pre-flight gate**: `GET /api/stt/status` blocks "Enter interview" until the provider is ready; `POST /api/stt/preflight-check` transcribes a read-aloud sentence (browser-decoded 16kHz PCM16) and requires >= 80% word match.
- **Adaptive mode** (INTERVIEW_MODE=adaptive, R3.4c): LLM streaming turn decisions, follow-ups, probes — kept intact behind the flag with full barge-in.
- Speech loop (adaptive): Candidate speaks -> Silero VAD + Smart Turn v3 -> single streaming Gemini turn decision (<350ms TTFT) -> Kokoro-82M sentence-streamed TTS (<200ms). Turns committed in real-time to PostgreSQL (`interview_transcript_turns`) with latency and interruption tracking; 15m pause/resume reconnect support.

### 6. Triple-Phase RAG Matrix
- **Pre-Interview:** Candidate resume chunks matching JD competencies for tailored question synthesis.
- **In-Interview (JIT RAG):** Active rubric anchors (L3/L4) injected just-in-time to keep live prompts <800 tokens for ultra-low TTFT.
- **Post-Interview:** Full transcript chunks retrieved to extract verbatim timestamped quotes for each competency.

### 7. Post-Interview Rubric Scoring & Judge
- Gemini 3.8 Flash Evidence-Anchored Judge evaluates full transcript with verbatim normalized substring quote verification.
- Enforces strict quote verification (automatic downgrade to NOT_ASSESSED if zero verified quotes), deterministic weighted aggregation via `job_skills.weight_percentage`, P0 NOT_ASSESSED cap, second-pass median aggregation on borderline scores, and candidate-safe redaction.
- Evidence-backed audit report with timestamped quotes and proctoring timeline.

### 8. Dashboards
- **Recruiter:** Job management, applicant leaderboard, side-by-side video/audio & transcript replay, competency radar chart, expandable evidence accordion, PDF export.
- **Candidate:** Application status tracker, hardware pre-flight check (camera, mic volume visualizer, STT/TTS sample test), and actionable candidate feedback report.

---

## Local Development & Quick Start Commands

### 1. Database Management
- **Local PostgreSQL Connection**: `postgresql+asyncpg://postgres:12qw@localhost:5432/Candidly%20AI`
- **Wipe Database & Uploads Cleanly**:
  ```bash
  PYTHONPATH=. ./.venv/bin/python scripts/wipe_database.py
  ```

### 2. Running Services
- **Backend (FastAPI)**:
  ```bash
  source .venv/bin/activate
  uvicorn backend.app.main:app --host 0.0.0.0 --port 8000 --reload
  ```
- **Frontend (Vite + React)**:
  ```bash
  cd frontend
  npm run dev
  ```
  App will be accessible at: `http://localhost:5173`

### 3. Automated Test Suites
- **Full Auth, RBAC & Application Lifecycle Suite**:
  ```bash
  PYTHONPATH=. ./.venv/bin/python scripts/test_auth_and_application_flow.py
  ```
- **R3.5 simple-mode verification** (49 checks: no-LLM guarantee, commit paths, rule prompts, anchor_alt, time-skip, no-overlap, word budgets; add `--stt` for the real Apple helper smoke):
  ```bash
  PYTHONPATH=. ./.venv/bin/python scripts/verify_r3_5.py
  ```
- **STT review / Part 0 diagnosis** (offline replay of captured sessions -> `review/stt_review.html`):
  ```bash
  PYTHONPATH=. ./.venv/bin/python scripts/analyze_captured_audio.py
  PYTHONPATH=. ./.venv/bin/python scripts/build_stt_review.py
  ```
- **Live provider path drive** (real helper: warm session, echo gate, streamed partials, run_stt final):
  ```bash
  PYTHONPATH=. ./.venv/bin/python scripts/drive_provider_stt.py
  ```
- **Apple STT helper build** (debug + release, required before `apple_speechanalyzer` is usable):
  ```bash
  bash scripts/build_apple_stt.sh
  ```

---

## Multi-Provider Routing & Candidate Data Privacy Policy

### 1. Failover Policy & Data Routing
- **Primary Provider**: Google Gemini via official `google-genai` SDK (`GEMINI_API_KEY`).
- **Backup Provider**: TokenHarbor OpenAI-compatible API gateway (`API_KEY_LLM`, endpoint `https://tokenharbor.ai/v1`).
- **Failover Triggers**: The circuit breaker trips to TokenHarbor **only** on transient infrastructure failures: HTTP 429 (rate limit / quota exhaustion), HTTP 5xx (500, 502, 503, 504), and network connect/read timeouts.
- **Strict Prohibition on Silent Failover for Dead Keys**: Authentication errors (HTTP 400, 401, 403, `API_KEY_INVALID`, permission denied) never fail over. They immediately raise `ProviderAuthError` and surface a visible notification in the recruiter UI and `/api/health/ai`.
- **Candidate Data Boundary (`AI_FAILOVER_CANDIDATE_DATA`)**:
  - Candidate PII (resumes, work history, transcript turns, evidence scoring) is protected by `AI_FAILOVER_CANDIDATE_DATA=false` by default.
  - When `false`, candidate data operations fail fast with `CandidateDataFailoverBlockedError` rather than routing candidate PII to secondary endpoints.
  - Job blueprints and role templates contain no candidate data and may safely utilize TokenHarbor backup routing when Gemini is rate-limited.
  - The Gemini Files API is Gemini-proprietary; on the backup path, extracted text/structured data is used.

### 2. Upstream Data Disclosure & Hosting
- **Recipient**: When failover to TokenHarbor occurs, prompt data is transmitted to TokenHarbor (`tokenharbor.ai`) and routed to its selected upstream model providers (e.g. DeepSeek, MiniMax, or Moonshot hostings).
- **Hosting & Jurisdiction**: Processing may occur across US, EU, or regional data centers depending on upstream model routing.
- **Data Retention**: TokenHarbor and upstream providers do not train on API payload data per enterprise standard terms, but temporary operational logging (up to 30 days) may occur upstream for abuse monitoring.
- **Production Compliance Requirement**: **Customer legal and security approval is strictly required before toggling `AI_FAILOVER_CANDIDATE_DATA=true` in any production environment.**

---

## Agent Handoff Protocol
When transferring work between agents or logging off:
1. **Saving Context:** Run memory snapshot to `@modelcontextprotocol/server-memory` and `graphify scan .`.
2. **Resuming Context:** Read `PROJECT_BRAIN.md`, query `agent-memory`, inspect current repository state, and execute next backlog tasks.


